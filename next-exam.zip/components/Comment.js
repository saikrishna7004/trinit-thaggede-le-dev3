import React from 'react';

const Comment = ({ reply }) => {
    const options = {
        timeZone: 'Asia/Kolkata',
        hour12: true,
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: 'numeric',
        minute: 'numeric',
    };

    return (
        <div className="comment-container my-4">
            <div className="comment-header">
                <div className="profile-info">
                    <img src={reply.user.image} alt={reply.user.firstName} className="profile-image rounded-circle" width={45} height={45} />
                    <div className="user-details">
                        <p className="user-name">{reply.user.firstName} {reply.user.lastName}</p>
                        <p className="posted-time">{new Date(reply.createdAt).toLocaleString('en-US', options)}</p>
                    </div>
                </div>
            </div>
            <div className="comment-content">
                <p>{reply.body}</p>
            </div>
        </div>
    );
};

export default Comment;
