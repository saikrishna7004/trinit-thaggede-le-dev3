// components/ForumCard.js
import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const ForumCard = ({ title, discussion, content, date }) => {
    return (
        <div className="card mb-3">
            <div className="card-body">
                <h5 className="card-title">{title}</h5>
                <h6 className="card-subtitle mb-2 text-muted">{date}</h6>
                <p className="card-text">{content}</p>
                <a href="#" className="btn btn-primary">
                    Read More
                </a>
            </div>
        </div>
    );
};

export default ForumCard;
