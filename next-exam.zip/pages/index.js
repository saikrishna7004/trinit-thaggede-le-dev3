import Head from 'next/head';
import Link from 'next/link';
import Image from 'next/image';

export default function Home() {
	return (
		<div>
			<Head>
				<title>Recurse - The Technical Club</title>
				<link rel="icon" href="/favicon.ico" />
			</Head>

			<main className='my-5'>
				<section className="hero text-center d-flex align-items-center" style={{minHeight: '65vh', marginBottom: '20vh', marginTop: '10vh'}}>
					<div className="container">
						<Image className="mb-4" src='/recurse-logo-white.png' alt="Logo" width={265} height={140} />
						<h1>Welcome to Recurse - The Technical Club</h1>
						<p>Empowering students to explore, innovate, and excel in technology.</p>
						Follow us on <Link href="https://www.instagram.com/recurse.official" target="_blank" rel="noopener noreferrer" className='url'>
							Instagram
						</Link>
					</div>
				</section>

				<section className="hero text-center d-flex align-items-center" style={{minHeight: '65vh', marginBottom: '20vh'}}>
					<div className="container">
						<h1>Past Events</h1>
						<p className='my-4'>In the past year, recurse have conducted many events, few are listed here:</p>
						<div className='container' style={{display: 'flex', justifyContent: 'center'}}>
						<ul style={{textAlign: 'left'}}>
							<li>Navraas Online Treasure Hunt</li>
							<li>Code Sangram</li>
							<li>Innov8 Stackathon</li>
							<li>KMIT Eve Treasure Hunt</li>
						</ul>
						</div>
					</div>
				</section>

				{/* Add more sections for Activities, Projects, Blog/News, etc. */}

			</main>
		</div>
	);
}
