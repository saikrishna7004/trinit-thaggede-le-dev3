import { faEdit, faTrashAlt } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import React from 'react';

const Post = ({ reply, session, handleEditPost, handleDeletePost }) => {
    const options = {
        timeZone: 'Asia/Kolkata',
        hour12: true,
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: 'numeric',
        minute: 'numeric',
    };

    return (
        <div className="comment-container">
            <div className="comment-header">
                <div className="profile-info">
                    <div className="profile-image-container">
                        <img src={reply.created_by.image} alt={reply.created_by.firstName} className="profile-image rounded-circle" width={50} height={50} />
                    </div>
                    <div className="user-details">
                        <p className="user-name">{reply.created_by.firstName} {reply.created_by.lastName} {reply.created_by.type == 'admin' && <img className='mb-1 mx-1' style={{ pointerEvents: "none", userSelect: "none" }} src={'/verified.svg'} height='22px' width='22px' />}</p>
                        <p className="posted-time">{new Date(reply.createdAt).toLocaleString('en-US', options)}</p>
                    </div>
                </div>
            </div>
            <div className="comment-content">
                <div className="vertical-line"></div>
                <p>{reply.content}</p>
                <span className='d-flex align-center justify-content-between mt-3'>
                    <button className='btn custom-btn'>Replies</button>
                    {session?.user?._id === reply.created_by._id && (
                        <span className='d-flex align-center'>
                            <button className='btn text-white' onClick={() => handleEditPost(reply._id, reply)}><FontAwesomeIcon icon={faEdit} className="edit-icon" /></button>
                            <button className='btn text-white' onClick={() => handleDeletePost(reply._id)}><FontAwesomeIcon icon={faTrashAlt} className="delete-icon" /></button>
                        </span>
                    )}
                </span>
            </div>
        </div>
    );
};

export default Post;
